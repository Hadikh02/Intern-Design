using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class DeleteAdoptionFormModel : PageModel
    {
        public void OnGet()
        {
            int pid = (int)HttpContext.Session.GetInt32("PersonID");
            int id = Convert.ToInt32(Request.Query["id"]);
            new DAL().
            Response.Redirect($"/UserProfile?pid={pid}");
        }
    }
}
