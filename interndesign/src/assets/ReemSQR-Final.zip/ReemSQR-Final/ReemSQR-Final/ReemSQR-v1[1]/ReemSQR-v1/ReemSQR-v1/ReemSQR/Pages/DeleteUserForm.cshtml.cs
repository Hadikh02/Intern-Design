using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class DeleteUserFormModel : PageModel
    {
        public void OnGet()
        {
            int RehomingRequestID = int.Parse(Request.Query["rid"]);
            int PersonID = int.Parse(Request.Query["pid"]);
            new DAL().DeleteRehomingFormAndFilledForm(RehomingRequestID);
            Response.Redirect($"/UserProfile?pid={PersonID}");
        }
    }
}
