﻿namespace ReemSQR.Models
{
    public class RehomingList
    {
        public int PersonID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public DateOnly Age { get; set; }
        public int RequestID { get; set; }
        public string PetName { get; set; }
        public string PetType { get; set; }
        public int PetAge { get; set; }
        public string PetGender { get; set; }
        public string VaccineStatus { get; set; }
        public string PetHealth { get; set; }
        public string PetPassport { get; set; }
        public string ReasonForRehoming { get; set; }
        public string PetBehavior { get; set; }
        public string PetImage { get; set; }
        public DateTime RehomingRequestDate { get; set; }
        public int PetID { get; set; }

        public string PetDescription { get; set; }

        public RehomingList() { }

        public RehomingList(int PersonID, string FirstName, string LastName, string Email, string PhoneNumber, string Address, DateOnly Age, int RequestID, string PetName, string PetType, int PetAge, string PetGender, string VaccinationStatus, string PetHealth, string PetPassport, string ReasonForRehoming, string PetBehavior, string PetImage, DateTime RehomingRequestDate)
        {
            this.PersonID = PersonID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Address = Address;
            this.Age = Age;
            this.RequestID = RequestID;
            this.PetName = PetName;
            this.PetType = PetType;
            this.PetAge = PetAge;
            this.PetGender = PetGender;
            this.VaccineStatus = VaccinationStatus;
            this.PetHealth = PetHealth;
            this.PetPassport = PetPassport;
            this.ReasonForRehoming = ReasonForRehoming;
            this.PetBehavior = PetBehavior;
            this.PetImage = PetImage;
            this.RehomingRequestDate = RehomingRequestDate;
        }
        public RehomingList(string FirstName, string LastName, string Email, string PhoneNumber, string Address, DateOnly Age,int RequestID,  string PetName, string PetType, int PetAge, string PetGender, string VaccinationStatus, string PetHealth, string PetPassport, string ReasonForRehoming, string PetBehavior, string PetImage)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Address = Address;
            this.Age = Age;
            this.RequestID = RequestID;
            this.PetName = PetName;
            this.PetType = PetType;
            this.PetAge = PetAge;
            this.PetGender = PetGender;
            this.VaccineStatus = VaccinationStatus;
            this.PetHealth = PetHealth;
            this.PetPassport = PetPassport;
            this.ReasonForRehoming = ReasonForRehoming;
            this.PetBehavior = PetBehavior;
            this.PetImage = PetImage;
        }

        public RehomingList(int PetID, string PetName, string PetType, int PetAge, string PetPassport, string VaccinationStatus, string PetHealth, string desc, string PetImage, string PetGender)
        {
            this.PetID = PetID;
            this.PetName = PetName;
            this.PetType = PetType;
            this.PetAge = PetAge;
            this.PetPassport = PetPassport;
            this.VaccineStatus = VaccinationStatus;
            this.PetHealth = PetHealth;
            this.PetDescription = desc;
            this.PetImage = PetImage;
            this.PetGender = PetGender;
        }

    }
}
