﻿namespace ReemSQR.Models
{
    public class UserRehoming
    {
        public int  RequestID { get; set; }
        public string  PetName { get; set; }
        public string PetType { get; set; }

        public UserRehoming() { }
        public UserRehoming(int requestID, string petName, string petType)
        {
            RequestID = requestID;
            PetName = petName;
            PetType = petType;
        }
    }
}
