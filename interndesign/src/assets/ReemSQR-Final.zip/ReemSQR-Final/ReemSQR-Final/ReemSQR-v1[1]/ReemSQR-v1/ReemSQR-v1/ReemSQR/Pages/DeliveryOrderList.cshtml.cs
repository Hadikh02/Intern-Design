using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class DeliveryOrderListModel : PageModel
    {
        public int deliveryid { get; set; }
        public List<Items> Items = new List<Items>();
        public void OnGet()
        {
            deliveryid = int.Parse( Request.Query["did"].ToString());
            Items = new DAL().GetDeliveryOrderInfo(deliveryid);
        }
    }
}
