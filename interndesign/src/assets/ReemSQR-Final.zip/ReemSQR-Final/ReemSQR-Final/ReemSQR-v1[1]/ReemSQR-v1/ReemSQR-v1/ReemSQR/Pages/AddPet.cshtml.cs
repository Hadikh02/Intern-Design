using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AddPetModel : PageModel
    {
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public string PetType { get; set; }
        public string PetName { get; set; }
        public int? PetAge { get; set; }
        public string PetImage { get; set; }
        public string VaccineStatus { get; set; }
        public string HealthStatus { get; set; }
        public string PetPassport { get; set; }
        public string PetDescription { get; set; }
        public string ErrorMessage { get; set; } = "";
        public string PetGender { get; set; }

        public int? RehomingRequestID { get; set; }

        public IActionResult OnGet()
        {
            PetType = Request.Query["PetType"].ToString();
            PetName = Request.Query["PetName"].ToString();
            PetImage = Request.Query["PetImage"].ToString();
            VaccineStatus = Request.Query["VaccineStatus"].ToString();
            HealthStatus = Request.Query["HealthStatus"].ToString();
            PetPassport = Request.Query["PetPassport"].ToString();
            PetDescription = Request.Query["PetDescription"].ToString();
            PetGender = Request.Query["PetGender"].ToString();

            // Try parsing PetAge, handle parsing errors
            if (int.TryParse(Request.Query["PetAge"], out int age))
            {
                PetAge = age;
            }
            else
            {
                PetAge = null;
            }

            if (int.TryParse(Request.Query["RehomingRequestID"],out int rehomerequestid))
            {
                RehomingRequestID = rehomerequestid;
            }
            else
            {
                RehomingRequestID = null;
            }

            // Validation logic to check for empty or null values
            if (
                string.IsNullOrWhiteSpace(PetType) ||
                string.IsNullOrWhiteSpace(PetName) ||
                PetAge == null ||
                string.IsNullOrWhiteSpace(PetImage) ||
                string.IsNullOrWhiteSpace(VaccineStatus) ||
                string.IsNullOrWhiteSpace(HealthStatus) ||
                string.IsNullOrWhiteSpace(PetPassport) ||
                string.IsNullOrWhiteSpace(PetDescription)||
                RehomingRequestID == null||
                string.IsNullOrWhiteSpace(PetGender))
            {
            }

            return Page();
        }

        public void OnPost()
        {
            string PetName = Request.Form["petName"].ToString();
            string PetType = Request.Form["petType"].ToString();
            int PetAge = int.Parse(Request.Form["petAge"].ToString());
            string PetGender = Request.Form["petGender"].ToString();
            string PassPort = Request.Form["passport"].ToString();
            string Vaccine = Request.Form["vaccine"].ToString();
            string Health = Request.Form["health"].ToString();
            string Description = Request.Form["desc"].ToString();
            string PetImage = Request.Form["imagePath"].ToString();
            int? RehomingRequestID = null;

            if (int.TryParse(Request.Form["rehomeid"], out int result))
            {
                RehomingRequestID = result;
            }

            if (RehomingRequestID.HasValue)
            {
                // Do something when RehomingRequestID has a value
                new DAL().InsertPetForAdoption(PetName, PetType, PetAge, PassPort, Vaccine, Health, Description, PetImage, PetGender);
                new DAL().DeleteRehomingRequest(RehomingRequestID);
            }
            else
            {
                // Handle the case where RehomingRequestID is null
                new DAL().InsertPetForAdoption(PetName, PetType, PetAge, PassPort, Vaccine, Health, Description, PetImage, PetGender);

            }
        }
    }
}
