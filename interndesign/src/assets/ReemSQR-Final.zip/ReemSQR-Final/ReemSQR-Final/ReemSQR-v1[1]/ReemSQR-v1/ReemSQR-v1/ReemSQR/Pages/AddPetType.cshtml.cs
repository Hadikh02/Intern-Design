using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ReemSQR.Pages
{
    public class AddPetTypeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
