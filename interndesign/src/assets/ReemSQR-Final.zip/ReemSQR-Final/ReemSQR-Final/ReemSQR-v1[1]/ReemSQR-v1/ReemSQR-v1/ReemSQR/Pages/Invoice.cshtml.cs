using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class InvoiceModel : PageModel
    {
        public List<OrderItems> list = new List<OrderItems>();
        public Person personlist = new Person();
        public void OnGet()
        {
            int pid = (int)HttpContext.Session.GetInt32("PersonID");

            list = new DAL().GetOrders(pid);
            personlist = new DAL().GetUser(pid);
        }
    }
}
