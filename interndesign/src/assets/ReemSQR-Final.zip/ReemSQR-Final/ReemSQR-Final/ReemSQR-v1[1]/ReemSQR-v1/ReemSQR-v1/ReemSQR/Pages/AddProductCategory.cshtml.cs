using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AddProductCategoryModel : PageModel
    {
        public string MessageType { get; set; }
        public string Message { get; set; }
        public string Text { get; set; }
        public void OnGet()
        {
        }

        public void OnPost()
        {
            string cname = Request.Form["cname"];
            int res = new DAL().AddCategory(cname);
            if(res == 0)
            {
                MessageType = "error";
                Message = "This Category Name Already Exist!";
            }
            else
            {
                MessageType = "success";
                Message = "Added Successfully!";
            }
        }
    }
}
