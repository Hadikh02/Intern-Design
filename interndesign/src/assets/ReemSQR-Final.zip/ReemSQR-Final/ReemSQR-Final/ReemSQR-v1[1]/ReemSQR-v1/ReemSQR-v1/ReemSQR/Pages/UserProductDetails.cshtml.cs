using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UserProductDetailsModel : PageModel
    {
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public List<Products> list = new List<Products>();
        public int id { get; set; }
        public void OnGet()
        {
             id = Convert.ToInt32(Request.Query["pid"]);
            list = new DAL().GetProduct(id);
        }

        public void OnPost()
        {
            // Get "PersonID" from session as a nullable int
            int? pid = HttpContext.Session.GetInt32("PersonID");
            int preid = Convert.ToInt32(Request.Form["prid"]);

            // Check if the session value is null
            if (pid == null)
            {
                list = new DAL().GetProduct(preid);
                MessageType = "error";
                MessageText = "You should be logged in before purchasing any product";
                return; // Stop further execution
            }

            // Proceed only if "pid" is not null
            int id = Convert.ToInt32(Request.Form["id"]);
            int prid = Convert.ToInt32(Request.Form["prid"]);
            list = new DAL().GetProduct(prid);
            int cartid = new DAL().GenerateCart(pid.Value); // Use pid.Value to access the non-null value
            new DAL().AddItemToCart(cartid, id, 1);
            Response.Redirect("/cart");
        }

    }
}
