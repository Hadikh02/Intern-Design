﻿namespace ReemSQR.Models
{
    public class AdoptionDetails
    {
        public int PersonID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public DateTime DOB { get; set; }
        public int RequestID { get; set; }
        public string PetName { get; set; }
        public string PetType { get; set; }
        public int PetAge { get; set; }
        public string PetGender { get; set; }
        public string VaccineStatus { get; set; }
        public string PetHealth { get; set; }
        public string PetPassport { get; set; }
        public string PetImage { get; set; }
        public decimal Salaray { get; set; }
        public string FamilyStatus { get; set; }
        public string HomeEnvirmonet { get; set; }
        public string AdoptionHistory { get; set; }
        public string ReasonForAdoption { get; set; }
        public string RelationWithPets { get; set; }

        public string Email { get; set; }
        public AdoptionDetails() { }

        public AdoptionDetails(int personID, string firstName, string lastName, string phoneNumber, string address, DateTime dob, int requestID, string petName, string petType, int petAge, string petGender, string vaccineStatus, string petHealth, string petPassport, string petImage, decimal salaray, string familyStatus, string homeEnvirmonet, string adoptionHistory, string reasonForAdoption, string relationWithPets, string email)
        {
            PersonID = personID;
            FirstName = firstName;
            LastName = lastName;
            PhoneNumber = phoneNumber;
            Address = address;
            DOB = dob;
            RequestID = requestID;
            PetName = petName;
            PetType = petType;
            PetAge = petAge;
            PetGender = petGender;
            VaccineStatus = vaccineStatus;
            PetHealth = petHealth;
            PetPassport = petPassport;
            PetImage = petImage;
            Salaray = salaray;
            FamilyStatus = familyStatus;
            HomeEnvirmonet = homeEnvirmonet;
            AdoptionHistory = adoptionHistory;
            ReasonForAdoption = reasonForAdoption;
            RelationWithPets = relationWithPets;
            Email = email;
        }
    }

}
