﻿namespace ReemSQR.Models
{
    public class PetDetails
    {
        public int PetID { get; set; }
        public string PetName { get; set; }
        public int PetAge { get; set; }
        public string PetType { get; set; }
        public string VaccineStatus { get; set; }
        public string HealthStatus { get; set; }
        public string Passport { get; set; }
        public string PetGender { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public PetDetails() { }

        public PetDetails(int petID, string petName, int petAge, string petType, string vaccineStatus, string healthStatus, string passport, string petGender, string image, string description)
        {
            PetID = petID;
            PetName = petName;
            PetAge = petAge;
            PetType = petType;
            VaccineStatus = vaccineStatus;
            HealthStatus = healthStatus;
            Passport = passport;
            PetGender = petGender;
            Image = image;
            Description = description;
        }
    }
}
