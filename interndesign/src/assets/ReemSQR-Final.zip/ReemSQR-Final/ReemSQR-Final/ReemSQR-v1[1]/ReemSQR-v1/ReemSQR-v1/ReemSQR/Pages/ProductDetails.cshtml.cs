using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class ProductDetailsModel : PageModel
    {
        public List<Products> list = new List<Products>();
        public int id { get; set; }
        public void OnGet()
        {
            id = Convert.ToInt32(Request.Query["pid"]);
            list = new DAL().GetProduct(id);
        }

    }
}
