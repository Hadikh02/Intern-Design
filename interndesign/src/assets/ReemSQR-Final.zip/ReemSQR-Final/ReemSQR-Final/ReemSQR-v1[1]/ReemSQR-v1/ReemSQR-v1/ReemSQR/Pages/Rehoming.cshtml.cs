using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;
namespace ReemSQR.Pages
{
    public class RehomingModel : PageModel
    {
        public int? PersonID { get; set; }
        public Person SelectedPerson = new Person();
        public int PersonAge { get; set; }
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public void OnGet()
        {
            PersonID = HttpContext.Session.GetInt32("PersonID");

            if (PersonID.HasValue)
            {
                SelectedPerson = new DAL().GetOnePerson(PersonID.Value);
                PersonAge = DateTime.Now.Year - SelectedPerson.DOB.Year;
            }
            
        }
        public void OnPost()
        {
            PersonID = HttpContext.Session.GetInt32("PersonID");
            if (PersonID.HasValue)
            {
                SelectedPerson = new DAL().GetOnePerson(PersonID.Value);
                PersonAge = DateTime.Now.Year - SelectedPerson.DOB.Year;
                string PetName = Request.Form["petname"].ToString();
                string PetType = Request.Form["pettype"].ToString();
                string PetHealthStatus = Request.Form["healthstatus"].ToString();
                string PetVaccinationStatus = Request.Form["vaccinationstatus"].ToString();
                string PetGender = Request.Form["gender"].ToString();
                string PetPassport = Request.Form["petpassport"].ToString();
                string RehomingReason = Request.Form["rehomingreason"].ToString();
                string PetBehavior = Request.Form["petbehavior"].ToString();
                string Image = Request.Form["image"].ToString();
                int PetAge = int.Parse(Request.Form["petage"].ToString());

                if (PetPassport == "")
                {
                    PetPassport = "No";
                }
                else if (PetPassport == "on")
                {
                    PetPassport = "Yes";
                }

                new DAL().FillRehomingAdoptionForm(PetName, PetType, PetHealthStatus, PetVaccinationStatus, PetGender, PetPassport, RehomingReason, PetBehavior, Image, PetAge, PersonID.Value);

                MessageType = "success";
                MessageText = "Your rehoming request has been successfully sent to the admin. You will receive an email notification soon.";
            }
            else
            {
                MessageType = "error";
                MessageText = "You cannot submit the rehoming form without logging in first.";
            }
        }
    }
}
