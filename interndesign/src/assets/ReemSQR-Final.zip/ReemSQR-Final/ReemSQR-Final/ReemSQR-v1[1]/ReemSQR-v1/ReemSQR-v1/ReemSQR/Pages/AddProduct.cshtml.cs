using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AddProductModel : PageModel
    {
        public List<Category> list = new List<Category>();
        public void OnGet()
        {
            list = new DAL().GetCategories();
        }
        public void OnPost()
        {
            int cid = Convert.ToInt32(Request.Form["cid"]);
            string name = Request.Form["productname"];
            string brand = Request.Form["brand"];
            int quantity = Convert.ToInt32(Request.Form["quantity"]);
            decimal price = Convert.ToDecimal(Request.Form["price"]);
            string image = Request.Form["image"];
            string desc = Request.Form["desc"];


            new DAL().AddProduct(cid, name, brand, quantity, price, image, desc);

        }
    }
}
