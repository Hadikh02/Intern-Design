using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UpdatePetModel : PageModel
    {
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public int PetId { get; set; }
        public string PetName { get; set; }
        public int PetAge { get; set; }
        public string PetType { get; set; }
        public string Vaccine { get; set; }
        public string Health { get; set; }
        public string Passport { get; set; }
        public string PetGender { get; set; }
        public string PetDesc { get; set; }
        public string PetImage { get; set; }
        public void OnGet()
        {
            PetId = int.Parse(Request.Query["petid"]);
            PetDetails pet = new DAL().GetPetDetails(PetId);

            PetName = pet.PetName;
            PetAge = pet.PetAge;
            PetType = pet.PetType;
            Vaccine = pet.VaccineStatus;
            Health = pet.HealthStatus;
            Passport = pet.Passport;
            PetGender = pet.PetGender;
            PetDesc = pet.Description;
            PetImage = pet.Image;
        }
        public void OnPost()
        {
            int pid = int.Parse(Request.Form["pid"]);
            string pname = Request.Form["petName"].ToString();
            int page = int.Parse(Request.Form["petAge"]);
            string ptype = Request.Form["petType"].ToString();
            string vacc = Request.Form["vaccine"].ToString();
            string health = Request.Form["healthStatus"].ToString();
            string passport = Request.Form["petPassport"].ToString();
            string pgender = Request.Form["gender"].ToString();
            string desc = Request.Form["description"].ToString();
            string image = Request.Form["petImage"].ToString();

            new DAL().UpdatePetDetails(pid,pname,ptype,page,passport,vacc,health,desc,image,pgender);
            Response.Redirect("/PetForAdoption");
            MessageType = "success";
            MessageText = "The pet information has been successfully updated.";

        }
    }
}
