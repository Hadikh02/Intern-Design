﻿namespace ReemSQR.Models
{
    public class OrderItems
    {
        public int ProductId { get; set; }
        public int OrderID { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }

        public OrderItems(int productId, int orderID, string name, string image, decimal price, int quantity)
        {
            ProductId = productId;
            OrderID = orderID;
            Name = name;
            Image = image;
            Price = price;
            Quantity = quantity;
        }

    }
}
