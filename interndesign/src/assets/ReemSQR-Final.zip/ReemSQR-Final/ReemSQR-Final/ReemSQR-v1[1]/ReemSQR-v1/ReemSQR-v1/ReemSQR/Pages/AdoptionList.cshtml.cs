using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AdoptionListModel : PageModel
    {
        public List<PetsForAdoption> AdoptionList = new List<PetsForAdoption>();
        public void OnGet()
        {
            AdoptionList = new DAL().GetPetsForAdoptions();
        }
    }
}
