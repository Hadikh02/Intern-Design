﻿namespace ReemSQR.Models
{
    public class Users
    {
        public string FullName { get; set; }
        public DateTime DOB { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Logo { get; set; }
        public Users() { }
        public Users(string fullName, DateTime dOB, string address, string phoneNumber, string email, string logo)
        {
            FullName = fullName;
            DOB = dOB;
            Address = address;
            PhoneNumber = phoneNumber;
            Email = email;
            Logo = logo;
        }
    }
}
