using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;
using System.Security.Cryptography;

namespace ReemSQR.Pages
{
    public class UserProfileModel : PageModel
    {
        public int PersonID {  get; set; }
        public Person p = new Person();
        public List<UserRehoming> UserRehomingList = new List<UserRehoming>();
        public List<UserAdoption> UserAdoptionList = new List<UserAdoption>();
        public void OnGet()
        {
            PersonID = int.Parse(Request.Query["pid"]);

            p = new DAL().GetOnePerson(PersonID);
            UserRehomingList = new DAL().GetUserRehomingRequests(PersonID);
            UserAdoptionList = new DAL().GetUserAdoptionList(PersonID); 
        }

    }
}
