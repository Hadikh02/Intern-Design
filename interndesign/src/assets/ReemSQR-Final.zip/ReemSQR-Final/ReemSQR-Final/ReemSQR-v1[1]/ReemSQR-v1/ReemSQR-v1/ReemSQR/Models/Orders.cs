﻿namespace ReemSQR.Models
{
    public class Orders
    {
        public int OrderId { get; set; }
        public int PersonId { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public decimal TotalAmount { get; set; }
        public DateOnly OrderDate{ get; set; }
        public string Status {  get; set; }

        public Orders(int orderId, string fname, string lname, decimal totalAmount, DateOnly orderDate, string status)
        {
            OrderId = orderId;
            this.fname = fname;
            this.lname = lname;
            TotalAmount = totalAmount;
            OrderDate = orderDate;
            Status = status;
        }

        public Orders(int orderId, int personId, string fname, string lname, decimal totalAmount, DateOnly orderDate, string status)
        {
            OrderId = orderId;
            PersonId = personId;
            this.fname = fname;
            this.lname = lname;
            TotalAmount = totalAmount;
            OrderDate = orderDate;
            Status = status;
        }
    }
}
