using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UsersListModel : PageModel
    {
        public List<Users> UserList = new List<Users>();
        public void OnGet()
        {
            UserList = new DAL().GetAllUsers();
        }
    }
}
