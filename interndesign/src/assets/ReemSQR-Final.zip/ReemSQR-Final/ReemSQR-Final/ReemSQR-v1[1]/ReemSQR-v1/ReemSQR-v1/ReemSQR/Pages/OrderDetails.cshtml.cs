using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class OrderDetailsModel : PageModel
    {
        public List<Products> list = new List<Products>();
        public Delivery d = new Delivery();
        public Person person;
        public void OnGet()
        {
            int orderid = Convert.ToInt32(Request.Query["orderid"]);
            list = new DAL().GetProductsByOrderId(orderid);
            person = new DAL().GetUserByOrderID(orderid);
            d = new DAL().GetDelivery(orderid);
        }
    }
}
