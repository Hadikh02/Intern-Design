using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AdoptionPetDetailsModel : PageModel
    {
        public PetDetails pet = new PetDetails();
        public void OnGet()
        {
            int id = Convert.ToInt32(Request.Query["id"]);
            pet = new DAL().GetPetDetails(id);
        }
    }
}
