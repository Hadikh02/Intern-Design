using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;
using static System.Net.Mime.MediaTypeNames;

namespace ReemSQR.Pages
{
    public class PaymentOptionModel : PageModel
    {
        public string MessageType { get; set; }
        public string Message { get; set; }
        public string Text { get; set; }
        public void OnGet()
        {
        }

        public void OnPostDel()
        {
            decimal total = Convert.ToDecimal(Request.Form["total"]);
            int personid = (int)HttpContext.Session.GetInt32("PersonID");
            int cartid = new DAL().GenerateCart(personid);
            int orderid= new DAL().CreateOrder(personid, total, "Unpaid");
            if(orderid > 0)
            {
                new DAL().AddToOrder(cartid, orderid);
                new DAL().DeleteCart(personid);
                Response.Redirect("/Invoice");
            }
            else
            {
                MessageType = "error";
                Message = "Delivery Error";
                Text = "No Deliveries Available Right Now, Try Again Later";
            }
        }

        public void OnPostVisa()
        {
            decimal total = Convert.ToDecimal(Request.Form["total"]);
            string firstName = Request.Form["firstName"];
            string lastName = Request.Form["lastName"];
            string cardNumber = Request.Form["cardNumber"];
            string expiry = Request.Form["expiry"];
            int cvv = Convert.ToInt32(Request.Form["cvv"]);

            bool result = new DAL().VisaCheck(firstName, lastName, cardNumber, expiry, total, cvv);
            if (result)
            {
                int personid = (int)HttpContext.Session.GetInt32("PersonID");
                int cartid = new DAL().GenerateCart(personid);
                int orderid = new DAL().CreateOrder(personid, total, "Completed");
                if (orderid > 0)
                {
                    new DAL().AddToOrder(cartid, orderid);
                    new DAL().DeleteCart(personid);
                    Response.Redirect("/Invoice");
                }
                else
                {
                    MessageType = "error";
                    Message = "Delivery Error";
                    Text = "No Deliveries Available Right Now, Try Again Later";
                }

            }
        }
    }
}
