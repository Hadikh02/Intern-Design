using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class ShopModel : PageModel
    {
        public List<Products> list = new List<Products>();
        public List<Category> cat = new List<Category>();
        public void OnGet()
        {
            list = new DAL().GetProducts();
            cat = new DAL().GetCategories();
        }
    }
}
