using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UserAdoptionDetailsModel : PageModel
    {
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
        public int RequestID { get; set; }
        public AdoptionDetails details { get; set; } = new AdoptionDetails();
        public string Email { get; set; }
        public int Age { get; set; }
        public void OnGet()
        {
            try
            {
                RequestID = int.Parse(Request.Query["id"].ToString());
                details = new DAL().GetAdminAdoptionDetails(RequestID);

                Email = details.Email;
                Age = DateTime.Now.Year - details.DOB.Year;
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Failed to load adoption request details: {ex.Message}";
            }
        }
    }
}
