using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UpdateProductModel : PageModel
    {
        public Products list { get; set; }
        public void OnGet()
        {
            int id = Convert.ToInt32(Request.Query["id"]);
            list = new DAL().GetAProduct(id);
        }

        public void OnPost()
        {
            int id = Convert.ToInt32(Request.Query["id"]);
            string productname = Request.Form["productName"];
            decimal price = Convert.ToDecimal(Request.Form["price"]);
            int quantity = Convert.ToInt32(Request.Form["quantity"]);
            string brand = Request.Form["brand"];
            string description = Request.Form["description"];

            new DAL().UpdateProduct(id, productname, brand, price, quantity, description);
            list = new DAL().GetAProduct(id);
            Response.Redirect("/inventory");

        }
    }
}
