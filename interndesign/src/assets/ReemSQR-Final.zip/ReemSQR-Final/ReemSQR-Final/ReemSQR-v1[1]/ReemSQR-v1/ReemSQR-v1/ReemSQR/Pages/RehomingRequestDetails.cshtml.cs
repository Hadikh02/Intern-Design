using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;
using System.Net.Mail;

namespace ReemSQR.Pages
{
    public class RehomingRequestDetailsModel : PageModel
    {
        public string SuucessMessage { get; set; }
        public string ErrorMessage { get; set; }
        public int RehomingRequestID { get; set; }
        public int PersonID { get; set; }
        public string FormStatus { get; set; } = "";
        public RehomingList rehomingListsDetails = new RehomingList();
        public void OnGet()
        {
            PersonID = int.Parse(Request.Query["PersonID"].ToString());
            RehomingRequestID = int.Parse(Request.Query["RehomeRequestID"].ToString());

            rehomingListsDetails = new DAL().GetRehomingRequestDetails(PersonID, RehomingRequestID);
            FormStatus = new DAL().GetFormStatus(RehomingRequestID);
        }
        public void OnPostAcceptAsync()  // Make this async
        {
            try
            {
                PersonID = int.Parse(Request.Form["personId"].ToString());
                RehomingRequestID = int.Parse(Request.Form["requestId"].ToString());
                rehomingListsDetails = new DAL().GetRehomingRequestDetails(PersonID, RehomingRequestID);


                // Use the actual data from your model
                string PersonFullName = $"{rehomingListsDetails.FirstName} {rehomingListsDetails.LastName}";
                string PersonEmail = rehomingListsDetails.Email;
                string PetName = rehomingListsDetails.PetName;
                string PetType = rehomingListsDetails.PetType;

                AnswerRehomingRequestForm(PersonEmail, PersonFullName, PetName, PetType);
                FormStatus = new DAL().GetFormStatus(RehomingRequestID);
                new DAL().AcceptUpdateRehomingFormStatus(RehomingRequestID);
                // Redirect to success page or show success message

                SuucessMessage = "The email has been sent successfully.";
                Response.Redirect("./RehomingReports");

            }
            catch (Exception ex)
            {
                // Log the error
                // Redirect to error page or show error message
                ErrorMessage = "Failed to send the email.";
                Response.Redirect("./RehomingReports");
            }
        }
        public void OnPostRejectAsync()  // Make this async
        {
            try
            {
                PersonID = int.Parse(Request.Form["personId"].ToString());
                RehomingRequestID = int.Parse(Request.Form["requestId"].ToString());
                rehomingListsDetails = new DAL().GetRehomingRequestDetails(PersonID, RehomingRequestID);

                // Use the actual data from your model
                string PersonFullName = $"{rehomingListsDetails.FirstName} {rehomingListsDetails.LastName}";
                string PersonEmail = rehomingListsDetails.Email;
                string PetName = rehomingListsDetails.PetName;
                string PetType = rehomingListsDetails.PetType;
                string Message = Request.Form["rejectionReason"].ToString();

                RejectionAnswerRehomingRequestForm(PersonEmail, PersonFullName, PetName, PetType,Message);
                FormStatus = new DAL().GetFormStatus(RehomingRequestID);
                new DAL().RejectUpdateRehomingFormStatus(RehomingRequestID);
                new DAL().DeleteRehomingFormAndFilledForm(RehomingRequestID);
                // Redirect to success page or show success message
                SuucessMessage = "The email has been sent successfully.";
                Response.Redirect("./RehomingReports");
            }
            catch (Exception ex)
            {
                // Log the error
                // Redirect to error page or show error message
                ErrorMessage = "Failed to send the email.";
                Response.Redirect("./RehomingReports");
            }
        }

        private async Task AnswerRehomingRequestForm(string email, string fullname, string petname, string pettype)
        {
            try
            {
                using var mail = new MailMessage();
                mail.From = new MailAddress("Pet.AdoptionCenter@gmail.com");
                mail.To.Add(new MailAddress(email));
                mail.Subject = "Update on Your Pet Rehoming Request";
                mail.Body = $@"Hello {fullname},

We are pleased to inform you that your rehoming request for {petname}, a {pettype}, has been accepted.

You are welcome to bring your pet to us at your earliest convenience.

Thank you for trusting us with your pet's care.

Best regards,
Pet Adoption Center";
                mail.IsBodyHtml = false;

                using var smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential(
                    "hadi.khalil332@gmail.com",
                    "xoqiptpyzrndnnsi"
                );

                await smtp.SendMailAsync(mail);
            }
            catch (Exception ex)
            {
                // Log the error details
                throw new Exception($"Failed to send email to {email}: {ex.Message}", ex);
            }
        }
        private async Task RejectionAnswerRehomingRequestForm(string email, string fullname, string petname, string pettype, string Message)
        {
            try
            {
                using var mail = new MailMessage();
                mail.From = new MailAddress("Pet.AdoptionCenter@gmail.com");
                mail.To.Add(new MailAddress(email));
                mail.Subject = "Update on Your Pet Rehoming Request";
                mail.Body = Message;

                mail.IsBodyHtml = false;

                using var smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential(
                    "hadi.khalil332@gmail.com",
                    "xoqiptpyzrndnnsi"
                );

                await smtp.SendMailAsync(mail);
            }
            catch (Exception ex)
            {
                // Log the error details
                throw new Exception($"Failed to send email to {email}: {ex.Message}", ex);
            }
        }
    }
}
