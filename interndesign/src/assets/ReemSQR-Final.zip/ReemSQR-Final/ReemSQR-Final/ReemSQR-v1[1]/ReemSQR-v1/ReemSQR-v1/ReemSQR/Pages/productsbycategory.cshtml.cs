using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class productsbycategoryModel : PageModel
    {
        public List<Products> list = new List<Products>();
        public List<Category> cat = new List<Category>();
        public void OnGet()
        {
            int id = Convert.ToInt32(Request.Query["catid"]);
            list = new DAL().GetProductByCat(id);
            cat = new DAL().GetCategories();
        }
    }
}
