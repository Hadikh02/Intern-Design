using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class RehomingReportsModel : PageModel
    {
        public List<RehomingList> rehomingLists = new List<RehomingList>();
        public void OnGet()
        {
            rehomingLists = new DAL().GetAllRehomingRequest(); 
        }
    }
}
