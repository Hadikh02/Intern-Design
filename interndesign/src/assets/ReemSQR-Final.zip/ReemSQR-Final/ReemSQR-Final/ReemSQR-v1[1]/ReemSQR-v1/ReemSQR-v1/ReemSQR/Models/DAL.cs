﻿using System.Data.SqlClient;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using static System.Net.Mime.MediaTypeNames;
using System.Security.Cryptography;
namespace ReemSQR.Models
{
    public class DAL
    {
        string connection = "Data Source=.\\sqlexpress;Initial Catalog=Pets;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";
        SqlConnection? conn;
        SqlCommand? cmd;

        // Hadi Methods

        public int UserSignUp(string FirstName, string LastName, DateOnly DateOfBirth, string PhoneNumber, string Address, string Email, string Password)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();

                // Check if email already exists
                SqlCommand checkEmailCommand = new SqlCommand("SELECT COUNT(*) FROM Account WHERE Email = @Email", conn);
                checkEmailCommand.Parameters.AddWithValue("@Email", Email);

                int emailCount = (int)checkEmailCommand.ExecuteScalar();

                if (emailCount > 0)
                {
                    // Email already exists
                    return 1; // Indicates email exists
                }

                // Insert into Person and retrieve PersonID
                SqlCommand insertPersonCommand = new SqlCommand(
                    "INSERT INTO Person (FirstName, LastName, DOB, PhoneNumber, Address) OUTPUT INSERTED.PersonID VALUES (@FirstName, @LastName, @DOB, @PhoneNumber, @Address)",
                    conn
                );
                insertPersonCommand.Parameters.AddWithValue("@FirstName", FirstName);
                insertPersonCommand.Parameters.AddWithValue("@LastName", LastName);
                insertPersonCommand.Parameters.AddWithValue("@DOB", DateOfBirth);
                insertPersonCommand.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                insertPersonCommand.Parameters.AddWithValue("@Address", Address);

                int PersonID = (int)insertPersonCommand.ExecuteScalar();

                // Insert into Account
                SqlCommand insertAccountCommand = new SqlCommand(
                    "INSERT INTO Account (Email, PersonID, Password) VALUES (@Email, @PersonID, @Password)",
                    conn
                );
                insertAccountCommand.Parameters.AddWithValue("@Email", Email);
                insertAccountCommand.Parameters.AddWithValue("@PersonID", PersonID);
                insertAccountCommand.Parameters.AddWithValue("@Password", Password);

                insertAccountCommand.ExecuteNonQuery();
            }

            return 0; // Indicates successful creation
        }

        public int UserLogin(string Email, string Password)
        {
            int result = 0;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("select * from Account where Email = @Email", conn);
            command.Parameters.AddWithValue("@Email", Email);

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                result = 1;
                if (reader.GetString(2) == Password)
                {
                    result = 2;
                }
            }
            conn.Close();
            return result;
        }

        public void AdminSignUp(string FirstName, string LastName, string PhoneNumber, string Email, string Password)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("insert into Admin values(@FirstName, @LastName, @PhoneNumber, @Email, @Password)", conn);
            command.Parameters.AddWithValue("@FirstName", FirstName);
            command.Parameters.AddWithValue("@LastName", LastName);
            command.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@Password", Password);

            command.ExecuteNonQuery();
            conn.Close();
        }

        public int AdminLogin(string Email, string Password)
        {
            int result = 0;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("select * from Admin where AdminEmail = @Email", conn);
            command.Parameters.AddWithValue("@Email", Email);

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                result = 1;
                if (reader.GetString(5) == Password)
                {
                    result = 2;
                }
            }
            conn.Close();
            return result;
        }

        public int GetPersonID(string Email)
        {
            int PersonID = 0;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("select * from Account where Email = @Email", conn);
            command.Parameters.AddWithValue("@Email", Email);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                PersonID = reader.GetInt32(1);
            }
            conn.Close(); return PersonID;
        }

        public void FillRehomingAdoptionForm(string PetName, string PetType, string PetHealthStatus, string PetVaccineStatus, string PetGender, string PetPassport, string RehomingReason, string PetBehavior, string PetImage, int PetAge, int PersonID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand cmd = new SqlCommand("insert into RehomingRequest (RPetName, RPetType, RPetHealthStatus, RPetVaccineStatus, RPetGender, RPetPassport, ReHomingReason, PetBehavior, RPetImage, RPetAge, RehomingRequestDate, FormStatus) values (@PetName, @PetType, @PetHealthStatus, @PetVaccineStatus, @PetGender, @PetPassport, @ReHomingReason, @PetBehavior, @PetImage, @PetAge, @RehomingRequestDate, @FormStatus); SELECT SCOPE_IDENTITY();", conn);

            cmd.Parameters.AddWithValue("@PetName", PetName);
            cmd.Parameters.AddWithValue("@PetType", PetType);
            cmd.Parameters.AddWithValue("@PetHealthStatus", PetHealthStatus);
            cmd.Parameters.AddWithValue("@PetVaccineStatus", PetVaccineStatus);
            cmd.Parameters.AddWithValue("@PetGender", PetGender);
            cmd.Parameters.AddWithValue("@PetPassport", PetPassport);
            cmd.Parameters.AddWithValue("@ReHomingReason", RehomingReason);
            cmd.Parameters.AddWithValue("@PetBehavior", PetBehavior);
            cmd.Parameters.AddWithValue("@PetImage", PetImage);
            cmd.Parameters.AddWithValue("@PetAge", PetAge);
            cmd.Parameters.AddWithValue("@RehomingRequestDate", DateTime.Now);
            cmd.Parameters.AddWithValue("@FormStatus", "Pending");

            int RehomeRequestID = Convert.ToInt32(cmd.ExecuteScalar());

            conn.Close();

            SqlConnection con = new SqlConnection(connection);
            con.Open();

            SqlCommand command = new SqlCommand("insert into FilledForms (PersonID, ReHomeRequestID) values (@PersonID, @RehomeRequestID)", con);
            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomeRequestID);

            command.ExecuteNonQuery();
            con.Close();
        }

        public Person GetOnePerson(int PersonID)
        {
            Person p = null;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand cmd = new SqlCommand("select Person.FirstName, Person.LastName, Person.DOB, Person.PhoneNumber, Person.Address, Account.Email from Person inner join Account on Account.PersonID = Person.PersonID where Person.PersonID = @PersonID", conn);
            cmd.Parameters.AddWithValue("@PersonID", PersonID);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string FirstName = reader.GetString(0);
                string LastName = reader.GetString(1);
                DateOnly DOB = DateOnly.FromDateTime(reader.GetDateTime(2));
                string PhoneNumber = reader.GetString(3);
                string Address = reader.GetString(4);
                string Email = reader.GetString(5);

                p = new Person(FirstName, LastName, Email, PhoneNumber, Address, DOB);
            }
            conn.Close();
            return p;
        }

        public List<RehomingList> GetAllRehomingRequest()
        {
            List<RehomingList> rehomingLists = new List<RehomingList>();
            RehomingList rehomingList = null;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();


            SqlCommand command = new SqlCommand("SELECT Person.PersonID, Person.FirstName, Person.LastName, Account.Email, Person.PhoneNumber, Person.Address, Person.DOB, RehomingRequest.RehomeRequestID, RehomingRequest.RPetName, RehomingRequest.RPetType, RehomingRequest.RPetAge, RehomingRequest.RPetGender, RehomingRequest.RPetVaccineStatus, RehomingRequest.RPetHealthStatus, RehomingRequest.RPetPassport, RehomingRequest.ReHomingReason, RehomingRequest.PetBehavior, RehomingRequest.RPetImage, RehomingRequest.RehomingRequestDate, FilledForms.PersonID, FilledForms.RehomeRequestID FROM Person INNER JOIN FilledForms ON FilledForms.PersonID = Person.PersonID INNER JOIN RehomingRequest ON FilledForms.RehomeRequestID = RehomingRequest.RehomeRequestID INNER JOIN Account ON Account.PersonID = Person.PersonID", conn);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                int PersonID = reader.GetInt32(0);
                string FirstName = reader.GetString(1);
                string LastName = reader.GetString(2);
                string Email = reader.GetString(3);
                string PhoneNumber = reader.GetString(4);
                string Address = reader.GetString(5);
                DateOnly DOB = DateOnly.FromDateTime(reader.GetDateTime(6));
                int RequestID = reader.GetInt32(7);
                string PetName = reader.GetString(8);
                string PetType = reader.GetString(9);
                int PetAge = reader.GetInt32(10);
                string PetGender = reader.GetString(11);
                string VaccineStatus = reader.GetString(12);
                string HealthStatus = reader.GetString(13);
                string PetPassport = reader.GetString(14);
                string RehomingReason = reader.GetString(15);
                string PetBehavior = reader.GetString(16);
                string PetImage = reader.GetString(17);
                DateTime RehomingRequestDate = reader.GetDateTime(18);

                rehomingList = new RehomingList(PersonID, FirstName, LastName, Email, PhoneNumber, Address, DOB, RequestID, PetName, PetType, PetAge, PetGender, VaccineStatus, HealthStatus, PetPassport, RehomingReason, PetBehavior, PetImage, RehomingRequestDate);
                rehomingLists.Add(rehomingList);

            }
            conn.Close();
            return rehomingLists;
        }

        public RehomingList GetRehomingRequestDetails(int PersonID, int RehomingRequestID)
        {
            RehomingList RehomingRequestDetails = null;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();


            SqlCommand command = new SqlCommand("SELECT Person.FirstName, Person.LastName, Account.Email, Person.PhoneNumber, Person.Address, Person.DOB,ReHomingRequest.RehomeRequestID, RehomingRequest.RPetName, RehomingRequest.RPetType, RehomingRequest.RPetAge, RehomingRequest.RPetGender, RehomingRequest.RPetVaccineStatus, RehomingRequest.RPetHealthStatus, RehomingRequest.RPetPassport, RehomingRequest.ReHomingReason, RehomingRequest.PetBehavior, RehomingRequest.RPetImage, RehomingRequest.RehomingRequestDate, FilledForms.PersonID, FilledForms.RehomeRequestID FROM Person INNER JOIN FilledForms ON FilledForms.PersonID = Person.PersonID INNER JOIN RehomingRequest ON FilledForms.RehomeRequestID = RehomingRequest.RehomeRequestID INNER JOIN Account ON Account.PersonID = Person.PersonID WHERE Person.PersonID = @PersonID AND RehomingRequest.RehomeRequestID = @RehomingRequestID", conn);
            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@RehomingRequestID", RehomingRequestID);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string FirstName = reader.GetString(0);
                string LastName = reader.GetString(1);
                string Email = reader.GetString(2);
                string PhoneNumber = reader.GetString(3);
                string Address = reader.GetString(4);
                DateOnly DOB = DateOnly.FromDateTime(reader.GetDateTime(5));
                int rehomeid = reader.GetInt32(6);
                string PetName = reader.GetString(7);
                string PetType = reader.GetString(8);
                int PetAge = reader.GetInt32(9);
                string PetGender = reader.GetString(10);
                string VaccineStatus = reader.GetString(12);
                string HealthStatus = reader.GetString(12);
                string PetPassport = reader.GetString(13);
                string RehomingReason = reader.GetString(14);
                string PetBehavior = reader.GetString(15);
                string PetImage = reader.GetString(16);

                RehomingRequestDetails = new RehomingList(FirstName, LastName, Email, PhoneNumber, Address, DOB, rehomeid, PetName, PetType, PetAge, PetGender, VaccineStatus, HealthStatus, PetPassport, RehomingReason, PetBehavior, PetImage);
            }
            conn.Close();
            return RehomingRequestDetails;
        }

        public List<UserRehoming> GetUserRehomingRequests(int personID)
        {
            List<UserRehoming> UserRehomingList = new List<UserRehoming>();
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT \r\n\tR.RehomeRequestID,\r\n    R.RPetName, \r\n    R.RPetType\r\nFROM \r\n    FilledForms F\r\nINNER JOIN \r\n    ReHomingRequest R\r\nON \r\n    F.RehomeRequestID = R.RehomeRequestID\r\nWHERE \r\n    F.PersonID = @personId;\r\n ", conn);
            cmd.Parameters.AddWithValue("@personId", personID);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                UserRehoming userRehoming = new UserRehoming();
                userRehoming.RequestID = reader.GetInt32(0);
                userRehoming.PetName = reader.GetString(1);
                userRehoming.PetType = reader.GetString(2);

                UserRehomingList.Add(userRehoming);
            }
            return UserRehomingList;
        }

        public string GetFormStatus(int RehomingRequestID)
        {
            string FormStatus = "";

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("select FormStatus from ReHomingRequest where ReHomingRequest.RehomeRequestID = @RehomeRequestID", conn);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                FormStatus += reader.GetString(0);
            }
            conn.Close();
            return FormStatus;

        }

        public void AcceptUpdateRehomingFormStatus(int RehomingRequestID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("update ReHomingRequest set FormStatus = @FormStatus where RehomeRequestID = @RehomeRequestID", conn);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);
            command.Parameters.AddWithValue("@FormStatus", "Accepted");

            command.ExecuteNonQuery();
            conn.Close();
        }

        public void RejectUpdateRehomingFormStatus(int RehomingRequestID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("update ReHomingRequest set FormStatus = @FormStatus where RehomeRequestID = @RehomeRequestID", conn);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);
            command.Parameters.AddWithValue("@FormStatus", "Rejected");

            command.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteRehomingFormAndFilledForm(int RehomingRequestID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("delete from ReHomingRequest where ReHomingRequest.RehomeRequestID = @RehomeRequestID", conn);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);

            command.ExecuteNonQuery();
            conn.Close();

            SqlConnection con = new SqlConnection(connection);
            con.Open();

            SqlCommand comand = new SqlCommand("delete from FilledForms where FilledForms.ReHomeRequestID = @ReHomingRequestID", con);
            comand.Parameters.AddWithValue("@ReHomingRequestID", RehomingRequestID);

            comand.ExecuteNonQuery();
            con.Close();
        }

        public void InsertPetForAdoption(string PetName, string PetType, int PetAge, string PetPassport, string VaccineStatus, string HealthStatus, string PetDescription, string PetImage, string PetGender)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand(
                "INSERT INTO PetsForAdoption (RPetName, PetType, PetAge, PetPassport, VaccineStatus, HealthStatus, PetDescription, PetImage, PetGender) " +
                "VALUES (@PetName, @PetType, @PetAge, @PetPassport, @VaccineStatus, @HealthStatus, @PetDescription, @PetImage, @PetGender)",
                conn);

            command.Parameters.AddWithValue("@PetName", PetName);
            command.Parameters.AddWithValue("@PetType", PetType);
            command.Parameters.AddWithValue("@PetAge", PetAge);
            command.Parameters.AddWithValue("@PetPassport", PetPassport);
            command.Parameters.AddWithValue("@VaccineStatus", VaccineStatus);
            command.Parameters.AddWithValue("@HealthStatus", HealthStatus);
            command.Parameters.AddWithValue("@PetDescription", PetDescription);
            command.Parameters.AddWithValue("@PetImage", PetImage);
            command.Parameters.AddWithValue("@PetGender", PetGender);

            command.ExecuteNonQuery();
            conn.Close();


        }
        public void DeleteRehomingRequest(int? RehomingRequestID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("delete from ReHomingRequest where RehomeRequestID = @RehomeRequestID", conn);
            command.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);

            command.ExecuteNonQuery();
            conn.Close();

            SqlConnection con = new SqlConnection(connection);
            con.Open();

            SqlCommand commnd = new SqlCommand("delete from FilledForms where ReHomeRequestID = @RehomeRequestID", con);
            commnd.Parameters.AddWithValue("@RehomeRequestID", RehomingRequestID);

            commnd.ExecuteNonQuery();
            con.Close();
        }

        public List<RehomingList> GetPetsForAdoption()
        {
            List<RehomingList> rehomingLists = new List<RehomingList>();
            RehomingList rehomingList = null;

            SqlConnection conm = new SqlConnection(connection);
            conm.Open();

            SqlCommand command = new SqlCommand("select * from PetsForAdoption", conm);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                int PetID = reader.GetInt32(0);
                string PetName = reader.GetString(1);
                string PetType = reader.GetString(2);
                int PetAge = reader.GetInt32(3);
                string PetPassport = reader.GetString(4);
                string VaccineStatus = reader.GetString(5);
                string HealthStatus = reader.GetString(6);
                string PetDescription = reader.GetString(7);
                string PetImage = reader.GetString(8);
                string PetGender = reader.GetString(9);

                rehomingList = new RehomingList(PetID, PetName, PetType, PetAge, PetPassport, VaccineStatus, HealthStatus, PetDescription, PetImage, PetGender);
                rehomingLists.Add(rehomingList);
            }
            conm.Close();
            return rehomingLists;
        }
        public void DeletePet(int PetID)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand command = new SqlCommand("delete from PetsForAdoption where PetID = @PetID", conn);
            command.Parameters.AddWithValue("@PetID", PetID);

            command.ExecuteNonQuery();
            conn.Close();
        }

        public void UpdatePetDetails(int petId, string petName, string petType, int petAge, string petPassport, string vaccineStatus, string healthStatus, string petDescription, string petImage, string petGender)
        {
            string connectionString = connection;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = @"
            UPDATE PetsForAdoption
            SET 
                RPetName = @PetName,
                PetType = @PetType,
                PetAge = @PetAge,
                PetPassport = @PetPassport,
                VaccineStatus = @VaccineStatus,
                HealthStatus = @HealthStatus,
                PetDescription = @PetDescription,
                PetImage = @PetImage,
                PetGender = @PetGender
            WHERE PetID = @PetID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {

                    cmd.Parameters.AddWithValue("@PetName", petName);
                    cmd.Parameters.AddWithValue("@PetType", petType);
                    cmd.Parameters.AddWithValue("@PetAge", petAge);
                    cmd.Parameters.AddWithValue("@PetPassport", petPassport);
                    cmd.Parameters.AddWithValue("@VaccineStatus", vaccineStatus);
                    cmd.Parameters.AddWithValue("@HealthStatus", healthStatus);
                    cmd.Parameters.AddWithValue("@PetDescription", petDescription);
                    cmd.Parameters.AddWithValue("@PetImage", petImage);
                    cmd.Parameters.AddWithValue("@PetGender", petGender);
                    cmd.Parameters.AddWithValue("@PetID", petId);


                    cmd.ExecuteNonQuery();
                }
            }
        }

        public PetDetails GetPetDetails(int petid)
        {
            PetDetails pet = new PetDetails();

            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT * FROM PetsForAdoption WHERE PetID = @id", conn);
            cmd.Parameters.AddWithValue("@id", petid);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                pet.PetID = reader.GetInt32(0);
                pet.PetName = reader.GetString(1);
                pet.PetType = reader.GetString(2);
                pet.PetAge = reader.GetInt32(3);
                pet.Passport = reader.GetString(4);
                pet.VaccineStatus = reader.GetString(5);
                pet.HealthStatus = reader.GetString(6);
                pet.Description = reader.GetString(7);
                pet.Image = reader.GetString(8);
                pet.PetGender = reader.GetString(9);
            }
            return pet;
        }

        public List<PetsForAdoption> GetPetsForAdoptions()
        {
            List<PetsForAdoption> AdoptionList = new List<PetsForAdoption>();
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT * FROM PetsForAdoption", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                PetsForAdoption pet = new PetsForAdoption();

                pet.PetID = reader.GetInt32(0);
                pet.PetName = reader.GetString(1);
                pet.PetType = reader.GetString(2);
                pet.PetAge = reader.GetInt32(3);
                pet.Passport = reader.GetString(4);
                pet.VaccineStatus = reader.GetString(5);
                pet.HealthStatus = reader.GetString(6);
                pet.Description = reader.GetString(7);
                pet.Image = reader.GetString(8);
                pet.PetGender = reader.GetString(9);

                AdoptionList.Add(pet);
            }
            return AdoptionList;
        }

        public int FillAdoptionForm(int personId, int petId, string adoptionHistory, string familyStatus, string relationWithPets, string homeEnvironment, string adoptionReason, decimal salary)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    conn.Open();

                    // Insert into AdoptionRequests
                    SqlCommand cmd = new SqlCommand(
                        "INSERT INTO AdoptionRequests (PetID, UserAdoptionHistory, FamilyStatus, RelationWithPets, HomeEnvironment, AdoptionReason, UserSalary, AdoptionRequestStatus, RequestDate) " +
                        "VALUES (@PetID, @AdoptionHistory, @FamilyStatus, @RelationWithPets, @HomeEnvironment, @AdoptionReason, @Salary, @AdoptionRequestStatus, @date); " +
                        "SELECT SCOPE_IDENTITY();",
                        conn
                    );

                    cmd.Parameters.AddWithValue("@PetID", petId);
                    cmd.Parameters.AddWithValue("@AdoptionHistory", adoptionHistory);
                    cmd.Parameters.AddWithValue("@FamilyStatus", familyStatus);
                    cmd.Parameters.AddWithValue("@RelationWithPets", relationWithPets);
                    cmd.Parameters.AddWithValue("@HomeEnvironment", homeEnvironment);
                    cmd.Parameters.AddWithValue("@AdoptionReason", adoptionReason);
                    cmd.Parameters.AddWithValue("@Salary", salary);
                    cmd.Parameters.AddWithValue("@AdoptionRequestStatus", "Pending");
                    cmd.Parameters.AddWithValue("@date", DateTime.Now);
                    // Get the generated AdoptionRequestID
                    int adoptionRequestId = Convert.ToInt32(cmd.ExecuteScalar());

                    // Insert into FilledForm
                    SqlCommand command = new SqlCommand(
                        "INSERT INTO FilledForms (PersonID, AdoptionRequestID) VALUES (@PersonID, @AdoptionRequestID)",
                        conn
                    );
                    command.Parameters.AddWithValue("@PersonID", personId);
                    command.Parameters.AddWithValue("@AdoptionRequestID", adoptionRequestId);

                    command.ExecuteNonQuery();
                }

                return 1; // Success
            }
            catch (Exception)
            {
                return 0; // Error
            }
        }

        public AdoptionDetails GetAdminAdoptionDetails(int requestId)
        {
            AdoptionDetails adoption = new AdoptionDetails();

            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT Person.FirstName, Person.LastName, Person.PhoneNumber, Person.Address, Person.DOB,\r\nPetsForAdoption.RPetName, PetsForAdoption.PetType, PetsForAdoption.PetAge, PetsForAdoption.PetGender, PetsForAdoption.VaccineStatus, PetsForAdoption.HealthStatus,\r\nPetsForAdoption.PetPassport,\r\nAdoptionRequests.UserSalary, AdoptionRequests.FamilyStatus, AdoptionRequests.HomeEnvironment, AdoptionRequests.UserAdoptionHistory, AdoptionRequests.AdoptionReason\r\n, AdoptionRequests.RelationWithPets\r\n,Account.Email\r\nFROM Person INNER JOIN FilledForms ON FilledForms.PersonID = Person.PersonID\r\nINNER JOIN AdoptionRequests ON AdoptionRequests.AdoptionRequestID = FilledForms.AdoptionRequestID\r\nINNER JOIN PetsForAdoption ON PetsForAdoption.PetID = AdoptionRequests.PetID\r\nINNER JOIN Account ON Account.PersonID = Person.PersonID\r\nWHERE FilledForms.AdoptionRequestID = @id", conn);
            cmd.Parameters.AddWithValue("@id", requestId);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                adoption.FirstName = reader.GetString(0);
                adoption.LastName = reader.GetString(1);
                adoption.PhoneNumber = reader.GetString(2);
                adoption.Address = reader.GetString(3);
                adoption.DOB = reader.GetDateTime(4);
                adoption.PetName = reader.GetString(5);
                adoption.PetType = reader.GetString(6);
                adoption.PetAge = reader.GetInt32(7);
                adoption.PetGender = reader.GetString(8);
                adoption.VaccineStatus = reader.GetString(9);
                adoption.PetHealth = reader.GetString(10);
                adoption.PetPassport = reader.GetString(11);
                adoption.Salaray = reader.GetDecimal(12);
                adoption.FamilyStatus = reader.GetString(13);
                adoption.HomeEnvirmonet = reader.GetString(14);
                adoption.AdoptionHistory = reader.GetString(15);
                adoption.ReasonForAdoption = reader.GetString(16);
                adoption.RelationWithPets = reader.GetString(17);
                adoption.Email = reader.GetString(18);
            }
            return adoption;
        }

        public List<Adoption> GetAdminAdoptionList()
        {
            List<Adoption> AdminAdoptionList = new List<Adoption>();
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT CONCAT(Person.FirstName, ' ',Person.LastName) AS [FullName],\r\nPetsForAdoption.RPetName, PetsForAdoption.PetType, AdoptionRequests.RequestDate\r\n,PetsForAdoption.PetImage, AdoptionRequests.AdoptionRequestID\r\nFROM Person INNER JOIN FilledForms ON FilledForms.PersonID = Person.PersonID\r\nINNER JOIN AdoptionRequests ON AdoptionRequests.AdoptionRequestID = FilledForms.AdoptionRequestID\r\nINNER JOIN PetsForAdoption ON PetsForAdoption.PetID = AdoptionRequests.PetID", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Adoption adop = new Adoption();
                adop.UserFullName = reader.GetString(0);
                adop.PetName = reader.GetString(1);
                adop.PetType = reader.GetString(2);
                adop.RequestDate = reader.GetDateTime(3);
                adop.PetImage = reader.GetString(4);
                adop.RequestId = reader.GetInt32(5);

                AdminAdoptionList.Add(adop);
            }
            return AdminAdoptionList;
        }

        public void AcceptAdoptionRequest(int requestID)
        {
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("UPDATE AdoptionRequests SET AdoptionRequestStatus = @FormStatus where AdoptionRequestID = @id", conn);
            cmd.Parameters.AddWithValue("@id", requestID);
            cmd.Parameters.AddWithValue("@FormStatus", "Accepted");
            cmd.ExecuteNonQuery();
        }

        public void RejectAdoptionRequest(int requestID)
        {
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("UPDATE AdoptionRequests SET AdoptionRequestStatus = @FormStatus where AdoptionRequestID = @id", conn);
            cmd.Parameters.AddWithValue("@id", requestID);
            cmd.Parameters.AddWithValue("@FormStatus", "Rejected");
            cmd.ExecuteNonQuery();
        }

        public List<Users> GetAllUsers()
        {
            List<Users> UserList = new List<Users>();
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT \r\n    CONCAT(SUBSTRING(Person.FirstName, 1, 1), SUBSTRING(Person.LastName, 1, 1)) AS Logo,\r\n    CONCAT(Person.FirstName, ' ', Person.LastName) AS FullName, \r\n    Person.DOB, \r\n    Person.PhoneNumber,\r\n    Account.Email, Person.Address FROM Person\r\nINNER JOIN Account \r\nON Account.PersonID = Person.PersonID;\r\n", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Users user = new Users();
                user.Logo = reader.GetString(0);
                user.FullName = reader.GetString(1);
                user.DOB = reader.GetDateTime(2);
                user.PhoneNumber = reader.GetString(3);
                user.Email = reader.GetString(4);
                user.Address = reader.GetString(5);

                UserList.Add(user);
            }
            return UserList;
        }

        public List<PetsForAdoption> GetRandomPetsForAdoptions()
        {
            List<PetsForAdoption> AdoptionList = new List<PetsForAdoption>();
            conn = new SqlConnection(connection);
            conn.Open();

            // Update the query to select 3 random rows
            cmd = new SqlCommand("SELECT TOP 3 * FROM PetsForAdoption ORDER BY NEWID()", conn);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                PetsForAdoption pet = new PetsForAdoption
                {
                    PetID = reader.GetInt32(0),
                    PetName = reader.GetString(1),
                    PetType = reader.GetString(2),
                    PetAge = reader.GetInt32(3),
                    Passport = reader.GetString(4),
                    VaccineStatus = reader.GetString(5),
                    HealthStatus = reader.GetString(6),
                    Description = reader.GetString(7),
                    Image = reader.GetString(8),
                    PetGender = reader.GetString(9)
                };

                AdoptionList.Add(pet);
            }

            conn.Close();
            return AdoptionList;
        }

        //Hussein
        public List<Products> GetProducts()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products", conn);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public List<Products> GetProductByCat(int cid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products where CategoryID = @a", conn);
            cmd.Parameters.AddWithValue("@a", cid);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public List<Category> GetCategories()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from Category", conn);
            List<Category> ls = new List<Category>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                string name = reader.GetString(1);


                Category p = new Category(id, name);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }
        public List<Products> GetProduct(int pid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products where ProductID=@a", conn);
            cmd.Parameters.AddWithValue("@a", pid);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public Products GetAProduct(int pid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products where ProductID=@a", conn);
            cmd.Parameters.AddWithValue("@a", pid);
            Products p = null;
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);

            }
            conn.Close();
            return p;
        }

        public void AddProduct(int cid, string name, string brand, int quantity, decimal price, string image, string desc)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("insert into products(CategoryID,ProductName,Brand,Price,StockQuantity,Image,PetDescription) values (@a,@b,@c,@d,@e,@f,@g)", conn);
            cmd.Parameters.AddWithValue("@a", cid);
            cmd.Parameters.AddWithValue("@b", name);
            cmd.Parameters.AddWithValue("@c", brand);
            cmd.Parameters.AddWithValue("@d", price);
            cmd.Parameters.AddWithValue("@e", quantity);
            cmd.Parameters.AddWithValue("@f", image);
            cmd.Parameters.AddWithValue("@g", desc);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteProduct(int id)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("Delete from Products where productid=@a", conn);
            cmd.Parameters.AddWithValue("@a", id);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void UpdateProduct(int pid, string name, string brand, decimal price, int quantity, string description)
        {
            string query = @"
        UPDATE Products
        SET 
            ProductName = @ProductName,
            Brand = @Brand,
            Price = @Price,
            StockQuantity = @Quantity,
            PetDescription = @Description
        WHERE ProductID = @id";

            using (conn = new SqlConnection(connection))
            {
                using (cmd = new SqlCommand(query, conn))
                {
                    // Add parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@id", pid);
                    cmd.Parameters.AddWithValue("@ProductName", name);
                    cmd.Parameters.AddWithValue("@Brand", brand);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Description", description);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine("Product updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("No rows were updated. Check the ProductId or ensure it exists.");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        public List<Products> GetProductsOutOfStock()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products where QuantityStock = 0", conn);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public List<Products> GetProductsByHighPrice()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products ORDER BY price Desc", conn);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public List<Products> GetProductsByLowPrice()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from products ORDER BY price Asc", conn);
            List<Products> ls = new List<Products>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                int categoryid = reader.GetInt32(1);
                string ProductName = reader.GetString(2);
                string Brand = reader.GetString(3);
                decimal Price = reader.GetDecimal(4);
                int Quantity = reader.GetInt32(5);
                string Image = reader.GetString(6);
                string Description = reader.GetString(7);

                Products p = new Products(id, ProductName, categoryid, Brand, Price, Quantity, Image, Description);
                ls.Add(p);
            }
            conn.Close();
            return ls;
        }

        public int GenerateCart(int personid)
        {
            int cartid;
            conn = new SqlConnection(connection);
            SqlCommand cmd1 = new SqlCommand("SELECT CartID FROM Cart WHERE PersonID = @PersonID", conn);
            cmd1.Parameters.AddWithValue("@PersonID", personid);
            conn.Open();
            object result = cmd1.ExecuteScalar();

            if (result != null)
            {
                cartid = Convert.ToInt32(result);
            }
            else
            {
                cmd = new SqlCommand("INSERT INTO Cart (PersonID) OUTPUT INSERTED.CartID VALUES (@PersonID);", conn);
                cmd.Parameters.AddWithValue("@PersonID", personid);
                cartid = (int)cmd.ExecuteScalar();
            }


            conn.Close();
            return cartid;
        }

        public void AddItemToCart(int cartid, int productid, int quantity)
        {
            conn = new SqlConnection(connection);
            // Check if the item already exists in the cart
            SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM ContainsItems WHERE CartID = @cid AND ProductID = @pid", conn);
            checkCmd.Parameters.AddWithValue("@cid", cartid);
            checkCmd.Parameters.AddWithValue("@pid", productid);

            conn.Open();
            int count = (int)checkCmd.ExecuteScalar();
            conn.Close();

            if (count > 0)
            {
                // If the item exists, update the quantity
                SqlCommand updateCmd = new SqlCommand("UPDATE ContainsItems SET CartQuantity = CartQuantity + @q WHERE CartID = @cid AND ProductID = @pid", conn);
                updateCmd.Parameters.AddWithValue("@cid", cartid);
                updateCmd.Parameters.AddWithValue("@pid", productid);
                updateCmd.Parameters.AddWithValue("@q", quantity);

                conn.Open();
                updateCmd.ExecuteNonQuery();
                conn.Close();
            }
            else
            {
                SqlCommand insertCmd = new SqlCommand("INSERT INTO ContainsItems (ProductID, CartID, CartQuantity) VALUES (@pid,@cid,@q);", conn);
                insertCmd.Parameters.AddWithValue("@cid", cartid);
                insertCmd.Parameters.AddWithValue("@pid", productid);
                insertCmd.Parameters.AddWithValue("@q", quantity);

                conn.Open();
                insertCmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public List<CartItems> GetCartItems(int pid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT Products.ProductID, Products.ProductName, Products.Image, Products.Price, ContainsItems.CartQuantity, ContainsItems.CartID FROM Cart INNER JOIN ContainsItems ON Cart.CartID = ContainsItems.CartID INNER JOIN Products ON ContainsItems.ProductID = Products.ProductID WHERE Cart.PersonID = @PersonID;", conn);
            cmd.Parameters.AddWithValue("@PersonID", pid);
            List<CartItems> ls = new List<CartItems>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int productId = reader.GetInt32(reader.GetOrdinal("ProductID"));
                int cartId = reader.GetInt32(reader.GetOrdinal("CartID"));
                string productName = reader.GetString(reader.GetOrdinal("ProductName"));
                string image = reader.GetString(reader.GetOrdinal("Image"));
                decimal price = reader.GetDecimal(reader.GetOrdinal("Price"));
                int quantity = reader.GetInt32(reader.GetOrdinal("CartQuantity"));

                CartItems cart = new CartItems(cartId, productId, productName, image, price, quantity);
                ls.Add(cart);
            }
            conn.Close();
            return ls;
        }

        public void DecreaseQuantity(int pid, int cid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("UPDATE ContainsItems SET CartQuantity = CartQuantity - 1 WHERE ProductID = @ProductID AND CartID = @CartID AND CartQuantity > 1;", conn);
            cmd.Parameters.AddWithValue("@ProductID", pid);
            cmd.Parameters.AddWithValue("@CartID", cid);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void IncreaseQuantity(int pid, int cid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("UPDATE ContainsItems SET CartQuantity = CartQuantity + 1 WHERE ProductID = @ProductID AND CartID = @CartID;", conn);
            cmd.Parameters.AddWithValue("@ProductID", pid);
            cmd.Parameters.AddWithValue("@CartID", cid);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public Person GetUser(int pid)
        {
            Person? person = null;
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT * FROM Person JOIN Account ON Person.PersonID = Account.PersonID WHERE Person.PersonID = @pid", conn);
            cmd.Parameters.AddWithValue("@pid", pid);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string fname = reader.GetString(1);
                string lname = reader.GetString(2);
                DateOnly dob = DateOnly.FromDateTime(reader.GetDateTime(3));
                string phn = reader.GetString(4);
                string address = reader.GetString(5);
                string email = reader.GetString(6);

                person = new Person(fname, lname, email, phn, address, dob);
            }
            conn.Close();
            return person;
        }

        public int CreateOrder(int personId, decimal totalAmount, string orderStatus)
        {
            using (conn = new SqlConnection(connection))
            {
                conn.Open();

                // Check if there are any deliveries in the database
                string checkDeliveriesQuery = "SELECT COUNT(*) FROM Delivery";
                int deliveryCount = 0;

                using (SqlCommand checkCmd = new SqlCommand(checkDeliveriesQuery, conn))
                {
                    deliveryCount = Convert.ToInt32(checkCmd.ExecuteScalar());
                }

                // If no deliveries exist, return 0
                if (deliveryCount == 0)
                {
                    return 0;
                }

                // Select a random DeliveryID
                string getRandomDeliveryIdQuery = "SELECT TOP 1 DeliveryID FROM Delivery ORDER BY NEWID()";
                int deliveryId = 0;

                using (SqlCommand getDeliveryIdCmd = new SqlCommand(getRandomDeliveryIdQuery, conn))
                {
                    object result = getDeliveryIdCmd.ExecuteScalar();
                    deliveryId = Convert.ToInt32(result);
                }

                // Insert the new order and get the OrderID
                string insertOrderQuery = "INSERT INTO [Orders] (PersonID, OrderDate, TotalAmount, OrderStatus, DeliveryID) VALUES (@PersonID, @OrderDate, @TotalAmount, @OrderStatus, @DeliveryID); SELECT SCOPE_IDENTITY();";
                int orderId = 0;

                using (SqlCommand cmd = new SqlCommand(insertOrderQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@PersonID", personId);
                    cmd.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                    cmd.Parameters.AddWithValue("@OrderStatus", orderStatus);
                    cmd.Parameters.AddWithValue("@DeliveryID", deliveryId);

                    object orderIdObj = cmd.ExecuteScalar();
                    if (orderIdObj != null)
                    {
                        orderId = Convert.ToInt32(orderIdObj);
                    }
                }

                conn.Close();
                return orderId;
            }
        }


        public void DeleteCart(int pid)
        {
            int cartid;
            conn = new SqlConnection(connection);
            SqlCommand cmd1 = new SqlCommand("SELECT CartID FROM Cart WHERE PersonID = @PersonID", conn);
            cmd1.Parameters.AddWithValue("@PersonID", pid);
            conn.Open();
            object result = cmd1.ExecuteScalar();
            cartid = Convert.ToInt32(result);
            cmd = new SqlCommand("Delete from ContainsItems Where cartid=@cartid;", conn);
            cmd.Parameters.AddWithValue("cartid", cartid);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand("Delete from Cart Where personID=@PersonID;", conn);
            cmd.Parameters.AddWithValue("@PersonID", pid);
            cmd.ExecuteNonQuery();

            conn.Close();
        }

        public void AddToOrder(int cartId, int orderId)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("INSERT INTO OrderItems (ProductID, OrderID, Quantity) SELECT ProductID,@OrderID,CartQuantity FROM ContainsItems WHERE CartID = @CartID", conn);

            cmd.Parameters.AddWithValue("@CartID", cartId);
            cmd.Parameters.AddWithValue("@OrderID", orderId);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public List<OrderItems> GetOrders(int pid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT oi.*,o.*,p.* FROM OrderItems oi JOIN Orders o ON oi.OrderID = o.OrderID JOIN Products p ON oi.ProductID = p.ProductID WHERE o.PersonID = @PersonID", conn);
            cmd.Parameters.AddWithValue("@PersonID", pid);
            List<OrderItems> ls = new List<OrderItems>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int ProductID = reader.GetInt32(0); // Column 0: ProductID
                int OrderID = reader.GetInt32(1);   // Column 1: OrderID
                int Quantity = reader.GetInt32(2); // Column 2: Quantity
                string name = reader.GetString(11);
                string image = reader.GetString(15);
                decimal price = reader.GetDecimal(13);

                OrderItems cart = new OrderItems(ProductID, OrderID, name, image, price, Quantity);
                ls.Add(cart);
            }
            conn.Close();
            return ls;
        }

        public List<Orders> GetAllOrders()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT p.*,o.* FROM Person p JOIN Orders o ON p.PersonID = o.PersonID;", conn);
            //cmd.Parameters.AddWithValue("PersonID", pid);
            List<Orders> ls = new List<Orders>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int personid = reader.GetInt32(0);
                string fname = reader.GetString(1);
                string lname = reader.GetString(2);
                int OrderID = reader.GetInt32(6);
                decimal totalAmount = reader.GetDecimal(9);
                DateOnly date = DateOnly.FromDateTime(reader.GetDateTime(8).Date);
                string status = reader.GetString(10);

                Orders cart = new Orders(OrderID, personid, fname, lname, totalAmount, date, status);
                ls.Add(cart);
            }
            conn.Close();
            return ls;
        }

        public bool VisaCheck(string firstName, string lastName, string cardNumber, string expiry, decimal totalprice, int cvv)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT COUNT(*) FROM Bank WHERE FullName = CONCAT(@FirstName, ' ', @LastName) AND CardID = @CardNumber AND cvv>= @cvv AND ExpiryDate >= @Expiry AND Amount >= @CartTotal", conn);
            cmd.Parameters.AddWithValue("@FirstName", firstName);
            cmd.Parameters.AddWithValue("@LastName", lastName);
            cmd.Parameters.AddWithValue("@CardNumber", cardNumber);
            cmd.Parameters.AddWithValue("@Expiry", expiry);
            cmd.Parameters.AddWithValue("@CartTotal", totalprice);
            cmd.Parameters.AddWithValue("@cvv", cvv);
            conn.Open();
            int count = (int)cmd.ExecuteScalar();
            bool valid = count > 0;
            return valid;
        }

        public List<Products> GetProductsByOrderId(int orderId)
        {
            string query = @"
        SELECT p.ProductID,p.CategoryID,p.ProductName,p.Brand,p.Price,p.StockQuantity,p.Image,p.PetDescription,oi.Quantity FROM OrderItems oi INNER JOIN Products p ON oi.ProductID = p.ProductID WHERE oi.OrderID = @OrderID";

            List<Products> ls = new List<Products>();

            using (conn = new SqlConnection(connection))
            using (cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@OrderID", orderId);

                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int pid = reader.GetInt32(0);
                        int cid = reader.GetInt32(1);
                        string productname = reader.GetString(2);
                        string brand = reader.GetString(3);
                        decimal price = reader.GetDecimal(4);
                        int stock = reader.GetInt32(5);
                        string Image = reader.GetString(6);
                        string desc = reader.GetString(7);
                        int quantity = reader.GetInt32(8);

                        Products p = new Products(pid, productname, cid, brand, price, stock, quantity, Image, desc);

                        ls.Add(p);
                    }
                    return ls;
                }
            }

        }

        public Person GetUserByOrderID(int orderid)
        {
            Person? person = null;
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT p.*, o.OrderID,o.OrderDate,o.OrderStatus FROM Orders o INNER JOIN Person p ON o.PersonID = p.PersonID INNER JOIN OrderItems oi ON o.OrderID = oi.OrderID WHERE o.OrderID = @OrderID;", conn);
            cmd.Parameters.AddWithValue("@OrderID", orderid);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string fname = reader.GetString(1);
                string lname = reader.GetString(2);
                string status = reader.GetString(8);
                DateOnly dob = DateOnly.FromDateTime(reader.GetDateTime(7));


                person = new Person(fname, lname, status, dob);
            }
            conn.Close();
            return person;
        }

        public List<Delivery> GetDeliveryList()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from Delivery", conn);

            List<Delivery> ls = new List<Delivery>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                string name = reader.GetString(1);
                string address = reader.GetString(2);
                string phn = reader.GetString(3);
                string email = reader.GetString(4);

                Delivery delivery = new Delivery(id, name, address, phn, email);
                ls.Add(delivery);
            }
            conn.Close();
            return ls;
        }

        public int AddCategory(string catname)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();

                // Check if the category already exists
                string checkQuery = "SELECT COUNT(*) FROM Category WHERE CategoryName = @name";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@name", catname);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        return 0;
                    }
                }

                string insertQuery = "INSERT INTO Category(CategoryName) VALUES (@name)";
                using (SqlCommand insertCmd = new SqlCommand(insertQuery, conn))
                {
                    insertCmd.Parameters.AddWithValue("@name", catname);
                    insertCmd.ExecuteNonQuery();
                }
            }

            return 1;
        }

        public void UpdateOrderStatus(int orderId)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();

                string query = "UPDATE Orders SET OrderStatus = @Status WHERE OrderID = @OrderID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", "Paid");
                    cmd.Parameters.AddWithValue("@OrderID", orderId);

                    cmd.ExecuteNonQuery();
                }
            }
        }
        
        public List<Delivery> GetAdminList()
        {
            List<Delivery> DeliveryList = new List<Delivery>();
            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT * FROM Delivery", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Delivery del = new Delivery();
                del.Id = reader.GetInt32(0);
                del.Name = reader.GetString(1);
                del.Address = reader.GetString(2);
                del.PhoneNumber = reader.GetString(3);
                del.Email = reader.GetString(4);

                DeliveryList.Add(del);
            }
            return DeliveryList;
        }

        public void AddDelivery(string DeliveryName,  string DeliveryAddress, string DeliveryPhoneNumber, string DeliveryEmail)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand cmd = new SqlCommand("insert into Delivery values (@Name,@Address,@Phone,@Email)",conn);
            cmd.Parameters.AddWithValue("@Name", DeliveryName);
            cmd.Parameters.AddWithValue("@Address", DeliveryAddress);
            cmd.Parameters.AddWithValue("@Phone",DeliveryPhoneNumber);
            cmd.Parameters.AddWithValue("@Email", DeliveryEmail);

            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public Delivery GetDelivery(int oid)
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("select * from Delivery inner join Orders on Delivery.DeliveryID = Orders.DeliveryID where OrderID = @a", conn);
            cmd.Parameters.AddWithValue("@a", oid);
            Delivery ls = null;
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                string name = reader.GetString(1);
                string address = reader.GetString(2);
                string phn = reader.GetString(3);
                string email = reader.GetString(4);

                ls = new Delivery(id,name,address,phn,email);
            }
            conn.Close();
            return ls;
        }

        public List<Items> GetDeliveryOrderInfo(int did)
        {
            List<Items> ls = new List<Items>();
            Items i = null;

            SqlConnection conn = new SqlConnection(connection);
            conn.Open();

            SqlCommand cmd = new SqlCommand("select Orders.OrderID, Orders.PersonID,OrderItems.ProductID,Person.FirstName, Person.LastName, Account.Email, Orders.OrderDate, Orders.TotalAmount, Orders.OrderStatus, Products.ProductName,OrderItems.Quantity from Orders inner join OrderItems on Orders.OrderID = OrderItems.OrderID inner join Products on OrderItems.ProductID = Products.ProductID inner join Person on Orders.PersonID = Person.PersonID inner join Account on Account.PersonID = Person.PersonID where Orders.DeliveryID = @a", conn);
            cmd.Parameters.AddWithValue("@a", did);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int orderid = reader.GetInt32(0);
                int personid = reader.GetInt32(1);
                int productid = reader.GetInt32(2);
                string fullname = reader.GetString(3) + reader.GetString(4);
                string email = reader.GetString(5);
                DateOnly orderdate = DateOnly.FromDateTime(reader.GetDateTime(6));
                decimal amount = reader.GetDecimal(7);
                string status = reader.GetString(8);
                string productname = reader.GetString(9);
                int qty = reader.GetInt32(10);
                i = new Items(orderid, personid, productid, fullname, email, orderdate, amount, status, productname, qty);
                ls.Add(i);

            }
            conn.Close();
            return ls;
        }

        public List<Orders> GetThreeOrders()
        {
            conn = new SqlConnection(connection);
            cmd = new SqlCommand("SELECT TOP 3 p.*,o.* FROM Person p JOIN Orders o ON p.PersonID = o.PersonID ORDER BY NEWID();", conn);
            //cmd.Parameters.AddWithValue("PersonID", pid);
            List<Orders> ls = new List<Orders>();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int personid = reader.GetInt32(0);
                string fname = reader.GetString(1);
                string lname = reader.GetString(2);
                int OrderID = reader.GetInt32(6);
                decimal totalAmount = reader.GetDecimal(9);
                DateOnly date = DateOnly.FromDateTime(reader.GetDateTime(8).Date);
                string status = reader.GetString(10);

                Orders cart = new Orders(OrderID, personid, fname, lname, totalAmount, date, status);
                ls.Add(cart);
            }
            conn.Close();
            return ls;
        }


        public List<UserAdoption> GetUserAdoptionList(int personID)
        {
            List<UserAdoption> UserAdoptionList = new List<UserAdoption>();

            conn = new SqlConnection(connection);
            conn.Open();
            cmd = new SqlCommand("SELECT AdoptionRequests.AdoptionRequestID, PetsForAdoption.RPetName, PetsForAdoption.PetType, AdoptionRequests.RequestDate, AdoptionRequests.AdoptionRequestStatus\r\nFROM PetsForAdoption \r\nINNER JOIN AdoptionRequests ON PetsForAdoption.PetID = AdoptionRequests.PetID\r\nINNER JOIN FilledForms ON FilledForms.AdoptionRequestID = AdoptionRequests.AdoptionRequestID\r\nWHERE FilledForms.PersonID = @personID\r\n", conn);
            cmd.Parameters.AddWithValue("@personID", personID);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                UserAdoption adop = new UserAdoption();
                adop.requestID = reader.GetInt32(0);
                adop.PetName = reader.GetString(1);
                adop.PetType = reader.GetString(2);
                adop.RequestDate = reader.GetDateTime(3);
                adop.FormStatus = reader.GetString(4);

                UserAdoptionList.Add(adop);
            }
            return UserAdoptionList;
        }


  
    }
}
