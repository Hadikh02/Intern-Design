using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AdminDashboardModel : PageModel
    {
        public List<Orders> list = new List<Orders>();
        public void OnGet()
        {
            list = new DAL().GetThreeOrders();
        }
    }
}
