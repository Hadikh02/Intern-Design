using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AddAdminModel : PageModel
    {
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public void OnGet()
        {
        }
        public void OnPost() {
            string FirstName = Request.Form["firstname"].ToString();
            string LastName = Request.Form["lastname"].ToString();
            string PhoneNumber = Request.Form["phonenumber"].ToString();
            string Email = Request.Form["email"].ToString();
            string Password = Request.Form["password"].ToString();

            new DAL().AdminSignUp(FirstName, LastName, PhoneNumber, Email, Password);
            MessageType = "success";
            MessageText = "Admin has been successfully added.";
        }    
    }
}
