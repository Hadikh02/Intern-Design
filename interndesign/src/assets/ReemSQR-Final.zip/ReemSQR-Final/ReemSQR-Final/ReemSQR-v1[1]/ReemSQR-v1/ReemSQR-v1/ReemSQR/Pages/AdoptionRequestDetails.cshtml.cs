using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;
using System.Net.Mail;

namespace ReemSQR.Pages
{
    public class AdoptionRequestDetailsModel : PageModel
    {
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
        public int RequestID { get; set; }
        public AdoptionDetails details { get; set; } = new AdoptionDetails();
        public string Email { get; set; }
        public int Age { get; set; }

        public void OnGet()
        {
            try
            {
                RequestID = int.Parse(Request.Query["id"].ToString());
                details = new DAL().GetAdminAdoptionDetails(RequestID);

                Email = details.Email;
                Age = DateTime.Now.Year - details.DOB.Year;
            }
            catch (Exception ex)
            {
                ErrorMessage = $"Failed to load adoption request details: {ex.Message}";
            }
        }

        public async Task OnPostAcceptAsync()
        {
            try
            {
                RequestID = int.Parse(Request.Form["requestId"].ToString());
                details = new DAL().GetAdminAdoptionDetails(RequestID);

                // Use the actual data from your model
                string fullName = $"{details.FirstName} {details.LastName}";
                string petName = details.PetName;
                string petType = details.PetType;

                await SendAdoptionAcceptanceEmail(details.Email, fullName, petName, petType);
                new DAL().AcceptAdoptionRequest(RequestID);

                SuccessMessage = "The email has been sent successfully.";
                Response.Redirect("./AdoptionReports");
            }
            catch (Exception ex)
            {
                ErrorMessage = "Failed to send the email.";
                Response.Redirect("./AdoptionReports");
            }
        }

        public async Task OnPostRejectAsync()
        {
            try
            {
                RequestID = int.Parse(Request.Form["requestId"].ToString());
                details = new DAL().GetAdminAdoptionDetails(RequestID);

                // Use the actual data from your model
                string fullName = $"{details.FirstName} {details.LastName}";
                string rejectionReason = Request.Form["rejectionReason"].ToString();

                await SendAdoptionRejectionEmail(details.Email, fullName, rejectionReason);
                new DAL().RejectAdoptionRequest(RequestID);

                SuccessMessage = "The email has been sent successfully.";
                Response.Redirect("./AdoptionReports");
            }
            catch (Exception ex)
            {
                ErrorMessage = "Failed to send the email.";
                Response.Redirect("./AdoptionReports");
            }
        }

        private async Task SendAdoptionAcceptanceEmail(string email, string fullName, string petName, string petType)
        {
            try
            {
                using var mail = new MailMessage
                {
                    From = new MailAddress("Pet.AdoptionCenter@gmail.com"),
                    Subject = "Adoption Request Approved",
                    Body = $@"Hello {fullName},

We are pleased to inform you that your adoption request for {petName}, a {petType}, has been approved.

Thank you for giving a loving home to one of our pets.

Best regards,
Pet Adoption Center",
                    IsBodyHtml = false
                };
                mail.To.Add(new MailAddress(email));

                using var smtp = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    UseDefaultCredentials = false,
                    Credentials = new System.Net.NetworkCredential("hadi.khalil332@gmail.com", "xoqiptpyzrndnnsi")
                };

                await smtp.SendMailAsync(mail);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to send email to {email}: {ex.Message}", ex);
            }
        }

        private async Task SendAdoptionRejectionEmail(string email, string fullName, string rejectionReason)
        {
            try
            {
                using var mail = new MailMessage
                {
                    From = new MailAddress("Pet.AdoptionCenter@gmail.com"),
                    Subject = "Adoption Request Update",
                    Body = $@"Hello {fullName},

We regret to inform you that your adoption request has been rejected for the following reason:

{rejectionReason}

Thank you for understanding.

Best regards,
Pet Adoption Center",
                    IsBodyHtml = false
                };
                mail.To.Add(new MailAddress(email));

                using var smtp = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    UseDefaultCredentials = false,
                    Credentials = new System.Net.NetworkCredential("hadi.khalil332@gmail.com", "xoqiptpyzrndnnsi")
                };

                await smtp.SendMailAsync(mail);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to send email to {email}: {ex.Message}", ex);
            }
        }
    }
}
