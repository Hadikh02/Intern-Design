using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class DeletePetModel : PageModel
    {
        public void OnGet()
        {
            int PetID = int.Parse(Request.Query["pid"].ToString());
            new DAL().DeletePet(PetID);
            Response.Redirect("/PetForAdoption");
        }
    }
}
