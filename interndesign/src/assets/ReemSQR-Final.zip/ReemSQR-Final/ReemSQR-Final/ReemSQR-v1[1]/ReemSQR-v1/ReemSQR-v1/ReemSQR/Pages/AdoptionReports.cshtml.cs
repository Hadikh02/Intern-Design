using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AdoptionReportsModel : PageModel
    {
        public List<Adoption> AdminAdoptionRequestList = new List<Adoption>();
        public void OnGet()
        {
            AdminAdoptionRequestList = new DAL().GetAdminAdoptionList();
        }
    }
}
