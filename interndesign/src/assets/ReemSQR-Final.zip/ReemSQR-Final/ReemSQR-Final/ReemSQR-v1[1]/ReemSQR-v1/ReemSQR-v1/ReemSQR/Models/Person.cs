﻿namespace ReemSQR.Models
{
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Status { get; set; }
        public DateOnly DOB { get; set; }

        public Person() { }
        public Person (string FirstName, string LastName, string Email, string PhoneNumber, string Address, DateOnly DOB)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Address = Address;
            this.DOB = DOB;
        }

        public Person(string firstName, string lastName, string status, DateOnly dOB)
        {
            FirstName = firstName;
            LastName = lastName;
            Status = status;
            DOB = dOB;
        }
    }
}
