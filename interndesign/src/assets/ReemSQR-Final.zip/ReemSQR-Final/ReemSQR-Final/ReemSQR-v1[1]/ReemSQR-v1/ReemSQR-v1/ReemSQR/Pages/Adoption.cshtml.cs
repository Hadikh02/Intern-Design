using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AdoptionModel : PageModel
    {
        public string Message { get; set; }
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public Person User { get; set; }
        public int Age;
        public void OnGet()
        {
            int personId = Convert.ToInt32(HttpContext.Session.GetInt32("PersonID"));
            User = new DAL().GetOnePerson(personId);    
            Age = DateTime.Now.Year - User.DOB.Year;
        }

        public void OnPost()
        {
            int petId = Convert.ToInt32(Request.Query["id"]);
            int personId = Convert.ToInt32(HttpContext.Session.GetInt32("PersonID"));

            decimal salary = Convert.ToDecimal(Request.Form["salary"]);
            string familyStatus = Request.Form["familyStatus"];
            string homeEnvironment = Request.Form["homeEnvironment"];
            string adoptionHistory = Request.Form["adoptionHistory"];
            string adoptionReason = Request.Form["adoptionReason"];
            string relationWithPets = Request.Form["relationWithPets"];

            int result = new DAL().FillAdoptionForm(personId, petId, adoptionHistory, familyStatus, relationWithPets, homeEnvironment, adoptionReason, salary);

            if(result == 1)
            {
                MessageType = "success";
                Message = "Adoption Request Sent";
                MessageText = "Your Adoption request has been successfully sent to the admin. You will receive an email notification soon.";

                User = new DAL().GetOnePerson(personId);
                Age = DateTime.Now.Year - User.DOB.Year;
                Response.Redirect($"./UserProfile?pid={personId}");

            }
            else
            {
                MessageType = "error";
                Message = "Adoption Request Error";
                MessageText = "An Error Ocuured While Request, Please Try Again Later.";
            }
        }
    }
}
