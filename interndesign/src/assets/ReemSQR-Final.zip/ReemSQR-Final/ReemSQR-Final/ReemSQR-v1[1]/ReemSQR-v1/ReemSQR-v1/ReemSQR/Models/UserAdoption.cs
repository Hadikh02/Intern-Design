﻿namespace ReemSQR.Models
{
    public class UserAdoption
    {
        public int requestID { get; set; }
        public string PetName { get; set; }
        public string PetType { get; set; }
        public DateTime RequestDate { get; set; }
        public string FormStatus { get; set; }


        public UserAdoption() { }   
        public UserAdoption(int requestID, string petName, string petType, DateTime requestDate, string formStatus)
        {
            this.requestID = requestID;
            PetName = petName;
            PetType = petType;
            RequestDate = requestDate;
            FormStatus = formStatus;
        }
    }
}
