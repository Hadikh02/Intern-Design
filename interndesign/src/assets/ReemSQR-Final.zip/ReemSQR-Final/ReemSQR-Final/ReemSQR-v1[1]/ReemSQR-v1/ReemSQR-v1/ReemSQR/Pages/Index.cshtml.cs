using System.Runtime.InteropServices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class IndexModel : PageModel
    {
        public List<PetsForAdoption> RandomPets = new List<PetsForAdoption>();

        private readonly ILogger<IndexModel> _logger;
        public int? PersonID { get; set; }

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

               public List<Category> cat = new List<Category>();
        public void OnGet()
        {
            PersonID = HttpContext.Session.GetInt32("PersonID");
            RandomPets = new DAL().GetRandomPetsForAdoptions();
            cat = new DAL().GetCategories();
        }

        public void OnPost()
        {
            HttpContext.Session.Clear();
        }
    }
}
