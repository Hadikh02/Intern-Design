using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class CartModel : PageModel
    {
        public List<CartItems> list = new List<CartItems>();
        public void OnGet()
        {
            int pid = (int)HttpContext.Session.GetInt32("PersonID");

            list = new DAL().GetCartItems(pid);
        }

        public void OnPostDec()
        {
            int quantity = Convert.ToInt32(Request.Form["quantity"]);
            int pid = Convert.ToInt32(Request.Form["productId"]);
            int cid = Convert.ToInt32(Request.Form["cartID"]);
            new DAL().DecreaseQuantity(pid,cid);
            Response.Redirect("/cart");
        }
        public void OnPostInc()
        {
            int quantity = Convert.ToInt32(Request.Form["quantity"]);
            int pid = Convert.ToInt32(Request.Form["productId"]);
            int cid = Convert.ToInt32(Request.Form["cartID"]);
            new DAL().IncreaseQuantity( pid, cid);
            Response.Redirect("/cart");

        }
    }
}
