using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class AddDeliveryModel : PageModel
    {
        public void OnGet()
        {
        }
        public void OnPost() { 
            string name = Request.Form["name"].ToString();
            string address = Request.Form["address"].ToString();
            string phone = Request.Form["phone"].ToString();
            string email = Request.Form["email"].ToString();

            new DAL().AddDelivery(name, address, phone, email);
        }
    }
}
