﻿namespace ReemSQR.Models
{
    public class Adoption
    {
        public int RequestId { get; set; }
        public string UserFullName { get; set; }
        public string PetName { get; set; }
        public string PetType { get; set; }
        public DateTime RequestDate { get; set; }
        public string PetImage { get; set; }
        public Adoption() { }
        public Adoption(int requestId, string userFullName, string petName, string petType, DateTime requestDate, string Image)
        {
            RequestId = requestId;
            UserFullName = userFullName;
            PetName = petName;
            PetType = petType;
            RequestDate = requestDate;
            PetImage = Image;
        }
    }
}
