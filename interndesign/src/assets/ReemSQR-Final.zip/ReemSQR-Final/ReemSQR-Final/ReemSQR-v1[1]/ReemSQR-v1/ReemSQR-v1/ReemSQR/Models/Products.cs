﻿namespace ReemSQR.Models
{
    public class Products
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public string Brand { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public int UserQuantity { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }

        public Products(int productId, string productName, int categoryId, string brand, decimal price, int quantity, string image, string description)
        {
            ProductId = productId;
            ProductName = productName;
            CategoryId = categoryId;
            Brand = brand;
            Price = price;
            Quantity = quantity;
            Image = image;
            Description = description;
        }

        public Products(string productName, int categoryId, string brand, decimal price, int quantity, string image, string description)
        {
            ProductName = productName;
            CategoryId = categoryId;
            Brand = brand;
            Price = price;
            Quantity = quantity;
            Image = image;
            Description = description;
        }

        public Products(string productName, int categoryId, string brand, decimal price, int quantity, string description)
        {
            ProductName = productName;
            CategoryId = categoryId;
            Brand = brand;
            Price = price;
            Quantity = quantity;
            Description = description;
        }

        public Products(int productId, string productName, int categoryId, string brand, decimal price, int quantity, int userQuantity, string image, string description)
        {
            ProductId = productId;
            ProductName = productName;
            CategoryId = categoryId;
            Brand = brand;
            Price = price;
            Quantity = quantity;
            UserQuantity = userQuantity;
            Image = image;
            Description = description;
        }
    }
}
