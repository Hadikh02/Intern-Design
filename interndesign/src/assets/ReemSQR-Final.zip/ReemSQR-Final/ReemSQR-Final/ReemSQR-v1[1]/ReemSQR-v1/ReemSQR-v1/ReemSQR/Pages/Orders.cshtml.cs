using System.Security.AccessControl;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class OrdersModel : PageModel
    {
        public List<Orders> list = new List<Orders>();
        public void OnGet()
        {
            list = new DAL().GetAllOrders();
        }

        public IActionResult OnPostUpdateStatus(int id)
        {
            new DAL().UpdateOrderStatus(id);
            list = new DAL().GetAllOrders();
            return Page();
        }
    }
}
