using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class DeliveryModel : PageModel
    {
        public List<Delivery> DeliveriesList = new List<Delivery>();
        public void OnGet()
        {
            DeliveriesList = new DAL().GetDeliveryList();
        }
    }
}
