﻿namespace ReemSQR.Models
{
    public class Items
    {
        public int OrderId { get; set; }
        public int PersonID { get; set; }
        public int productID { get; set; }
        public string PersonName { get; set; }
        public string PersonEmail { get; set; }
        public DateOnly OrderDate { get; set; }
        public decimal Amount { get; set; }
        public string OrderStatus { get; set; }
        public string ProductName { get; set; }
        public int ProductQuantity { get; set; }

        // Constructor to initialize all properties
        public Items(int orderId, int personID, int ProductID, string personName, string pemail, DateOnly orderDate, decimal amount, string orderStatus, string productName, int productQuantity)
        {
            OrderId = orderId;
            PersonID = personID;
            this.productID = productID;
            PersonName = personName;
            PersonEmail = pemail;
            OrderDate = orderDate;
            Amount = amount;
            OrderStatus = orderStatus;
            ProductName = productName;
            ProductQuantity = productQuantity;
        }
    }

}
