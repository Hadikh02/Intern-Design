using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class InventoryModel : PageModel
    {
        public List<Products> list = new List<Products>();

        public void OnGet()
        {
            list = new DAL().GetProducts();
        }
    }
}
