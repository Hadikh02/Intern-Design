using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class SignUpModel : PageModel
    {
        public string MessageType { get; set; }
        public string Message { get; set; }
        public string Text { get; set; }
        public void OnGet()
        {
        }
        public void OnPost() {
            string FirstName = Request.Form["firstName"].ToString();
            string LastName = Request.Form["lastName"].ToString();
            DateOnly DateOfBirth = DateOnly.Parse(Request.Form["dob"].ToString());
            string PhoneNumber = Request.Form["phonenumber"].ToString();
            string Address = Request.Form["address"].ToString();
            string Email = Request.Form["email"].ToString();
            string Password = Request.Form["password"].ToString();

            int res = new DAL().UserSignUp(FirstName,LastName,DateOfBirth, PhoneNumber, Address, Email, Password);
            if (res == 0) 
            {
                Response.Redirect("/SignIn");
            }
            else
            {
                MessageType = "error";
                Message = "Email Already Used";
                Text = "Try Another Email Address";
            }
        }
    }
}
