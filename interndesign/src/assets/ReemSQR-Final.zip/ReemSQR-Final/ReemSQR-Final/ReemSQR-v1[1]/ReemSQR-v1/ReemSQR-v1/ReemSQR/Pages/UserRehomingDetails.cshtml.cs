using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class UserRehomingDetailsModel : PageModel
    {
        public int rid { get; set; }
        public int personid { get; set; }
        public RehomingList rehomingListsDetails = new RehomingList();
        public void OnGet()
        {
            rid = int.Parse( Request.Query["rid"].ToString());
            personid = (int)HttpContext.Session.GetInt32("PersonID");
            rehomingListsDetails = new DAL().GetRehomingRequestDetails(personid, rid);
        }
    }
}
