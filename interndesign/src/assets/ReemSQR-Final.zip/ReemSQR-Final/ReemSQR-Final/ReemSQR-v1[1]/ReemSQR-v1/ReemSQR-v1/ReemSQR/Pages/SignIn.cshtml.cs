using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ReemSQR.Models;

namespace ReemSQR.Pages
{
    public class SignInModel : PageModel
    {
        public string MessageType { get; set; }
        public string MessageText { get; set; }
        public void OnGet()
        {
        }
        public void OnPost() {
            string Email = Request.Form["email"].ToString();
            string Password = Request.Form["password"].ToString();

            int UserLoginResult = new DAL().UserLogin(Email, Password);
            int PersonID = new DAL().GetPersonID(Email);

            if (UserLoginResult == 0)
            {
                MessageType = "error";
                MessageText = "Email or Password is incorrect";
            }
            else if (UserLoginResult == 1)
            {
                MessageType = "error";
                MessageText = "Password is incorrect";
            }
            else if(UserLoginResult == 2){
                HttpContext.Session.SetInt32("PersonID", PersonID);
                HttpContext.Session.SetString("Email", Email);

                Response.Redirect("/Index");
            }

            int AdminLoginResult = new DAL().AdminLogin(Email, Password);
            if (AdminLoginResult == 0)
            {
                MessageType = "error";
                MessageText = "Email or Password is incorrect";
            }
            else if (AdminLoginResult == 1)
            {
                MessageType = "error";
                MessageText = "Password is incorrect";
            }
            else if (AdminLoginResult == 2)
            {
                HttpContext.Session.SetString("Email", Email);
                Response.Redirect("/AdminDashboard");
            }
        }
    }
}
